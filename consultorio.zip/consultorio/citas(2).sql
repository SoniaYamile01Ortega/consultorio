-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2023 at 10:41 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citas`
--

-- --------------------------------------------------------

--
-- Table structure for table `citas`
--

CREATE TABLE `citas` (
  `citaNumero` int(11) NOT NULL,
  `citaFecha` date NOT NULL,
  `citaHora` time NOT NULL,
  `citaPaciente` int(11) NOT NULL,
  `citaMedico` int(11) NOT NULL,
  `citaConsultorio` int(11) NOT NULL,
  `citaEstado` varchar(100) NOT NULL,
  `citaObservaciones` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `consultorios`
--

CREATE TABLE `consultorios` (
  `conNumero` int(11) NOT NULL,
  `conNombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `medicos`
--

CREATE TABLE `medicos` (
  `medIdentificacion` int(11) NOT NULL,
  `cedula` varchar(30) NOT NULL,
  `medNombre` varchar(30) NOT NULL,
  `medApellidos` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicos`
--

INSERT INTO `medicos` (`medIdentificacion`, `cedula`, `medNombre`, `medApellidos`) VALUES
(1, '15.963.366', 'Juan Fernando ', 'Velazco'),
(2, '45.369.622.336.369', 'Ana María ', 'Caicedo Ortega');

-- --------------------------------------------------------

--
-- Table structure for table `pacientes`
--

CREATE TABLE `pacientes` (
  `paIdentificacion` int(11) NOT NULL,
  `paNombre` varchar(30) NOT NULL,
  `paApellidos` varchar(30) NOT NULL,
  `paFechaNacimiento` date NOT NULL,
  `paSexo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tratamientos`
--

CREATE TABLE `tratamientos` (
  `traNumero` int(11) NOT NULL,
  `traFechaAsignado` date NOT NULL,
  `traDescripcion` varchar(100) NOT NULL,
  `traFechaInicio` date NOT NULL,
  `traFechaFin` date NOT NULL,
  `trObservaciones` varchar(300) NOT NULL,
  `traPaciente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`citaNumero`),
  ADD UNIQUE KEY `citaConsultorio` (`citaConsultorio`),
  ADD KEY `citaPaciente` (`citaPaciente`),
  ADD KEY `citaMedico` (`citaMedico`);

--
-- Indexes for table `consultorios`
--
ALTER TABLE `consultorios`
  ADD PRIMARY KEY (`conNumero`);

--
-- Indexes for table `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`medIdentificacion`);

--
-- Indexes for table `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`paIdentificacion`);

--
-- Indexes for table `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD PRIMARY KEY (`traNumero`),
  ADD KEY `traPaciente` (`traPaciente`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `citas`
--
ALTER TABLE `citas`
  MODIFY `citaNumero` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `consultorios`
--
ALTER TABLE `consultorios`
  MODIFY `conNumero` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicos`
--
ALTER TABLE `medicos`
  MODIFY `medIdentificacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `paIdentificacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tratamientos`
--
ALTER TABLE `tratamientos`
  MODIFY `traNumero` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `citas`
--
ALTER TABLE `citas`
  ADD CONSTRAINT `fk_consultorios` FOREIGN KEY (`citaConsultorio`) REFERENCES `consultorios` (`conNumero`),
  ADD CONSTRAINT `fk_medicos` FOREIGN KEY (`citaMedico`) REFERENCES `medicos` (`medIdentificacion`),
  ADD CONSTRAINT `fk_pacientes` FOREIGN KEY (`citaPaciente`) REFERENCES `pacientes` (`paIdentificacion`);

--
-- Constraints for table `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD CONSTRAINT `fk_paciente` FOREIGN KEY (`traPaciente`) REFERENCES `pacientes` (`paIdentificacion`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
